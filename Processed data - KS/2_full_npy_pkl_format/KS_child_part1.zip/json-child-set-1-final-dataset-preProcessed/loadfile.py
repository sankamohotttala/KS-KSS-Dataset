#load pickle file
import pickle
import numpy as np
#load pickle data from file

# path_pick='data_label.pkl' #set 1
path=r'F:\Data Sets\Skeleton\2D\Child\Kinetics Subsets\All final subsets\json-child-set-2-final-dataset-preProcessed' #set 2
path_pick=path+'/data_label.pkl'

with open(path_pick, 'rb') as f:
    data = pickle.load(f)
# print(data)
pass

#load a numpy array from file

# path_numpy='data.npy'
path_numpy=path+'/data.npy'

data=np.load(path_numpy)
print(data.shape)
pass

